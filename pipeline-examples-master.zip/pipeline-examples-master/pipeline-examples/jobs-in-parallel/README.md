This code snippet will run the same job multiple times in parallel 
a usecase of that is, for example, a system test or load test that requires several workers with heavy i/o or compute.
it allows you to run each worker on a different machine to distribute the i/o or compute

