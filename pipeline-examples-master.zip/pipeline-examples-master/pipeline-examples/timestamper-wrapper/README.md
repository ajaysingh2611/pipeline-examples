# Synopsis

This shows usage of a simple build wrapper, specifically the
Timestamper plugin, which adds timestamps to the console output.

